## Add the bookmarks
#### Draw the link to your bookmarks bar
Click on a bookmark to show a dialog to set a new title.
### [Set Expanded Title](javascript:$("<script src='https://juegostrower.github.io/Expanded-Title/direct.js'>").appendTo(document.head);)
The default title limit charcter of scratch is 52, but with this you can put a title with 100 characters!!!
When you click it a dilog to write the new title will appear!!!!
### [Set animated thumbnail](javascript:$("<script src='https://juegostrower.github.io/Set-Animated-Thumbnail/direct.js'>").appendTo(document.head);setTimeout(function(){document.getElementById("autothumb").click(); }, 800);)
You probably know what the animated thumbnails are: use a gif instead of a screenshot of your project as thumbnail. Also, you can put a different static image.
